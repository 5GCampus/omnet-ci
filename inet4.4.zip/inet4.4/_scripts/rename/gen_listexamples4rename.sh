#!/bin/sh

find ../../examples -name "*.ned" -o -name "*.ini" -o -name "*.xml" >filelist_examples.txt
