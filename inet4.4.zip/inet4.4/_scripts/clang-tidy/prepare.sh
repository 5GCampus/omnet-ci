bear make -j10 -B MODE=debug
