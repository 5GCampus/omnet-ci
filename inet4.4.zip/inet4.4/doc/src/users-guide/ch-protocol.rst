.. role:: raw-latex(raw)
   :format: latex
..

.. _ug:cha:protocol:

Accessory Protocols
===================

.. _ug:sec:protocol:overview:

Overview
--------
