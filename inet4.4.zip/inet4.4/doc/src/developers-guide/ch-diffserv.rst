:orphan:

.. _dg:cha:diffserv:

Differentiated Services
=======================

TODO communication between components
