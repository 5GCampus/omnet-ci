:orphan:

.. _dg:cha:environment:

The Physical Environment
========================

TODO C++ interface
