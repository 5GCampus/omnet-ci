:orphan:

.. _dg:cha:sctp:

The SCTP Model
==============

Overview
--------

Blah blah blah
