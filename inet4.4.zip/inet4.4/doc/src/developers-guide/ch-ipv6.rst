:orphan:

.. _dg:cha:ipv6:

IPv6 and Mobile IPv6
====================

TODO how to send and receive

TODO C++ interfaces among members of the protocol family

TODO how to extend
