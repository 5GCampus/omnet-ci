:orphan:

.. _dg:cha:power:

The Power Model
===============

TODO C++ interface

Energy Consumer Models
----------------------

TODO C++ interface

Energy Generator Models
-----------------------

TODO C++ interface

Energy Storage Models
---------------------

TODO C++ interface
