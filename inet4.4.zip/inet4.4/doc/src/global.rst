.. role:: protocol
   :class: protocol

.. role:: var(code)
   :class: literal-cpp

.. role:: fun(code)
   :class: literal-cpp

.. role:: cpp(code)
   :class: literal-cpp

.. role:: gate(code)
   :class: literal-ned

.. role:: ini(code)
   :class: literal-ini

.. role:: par(code)
   :class: literal-ini
